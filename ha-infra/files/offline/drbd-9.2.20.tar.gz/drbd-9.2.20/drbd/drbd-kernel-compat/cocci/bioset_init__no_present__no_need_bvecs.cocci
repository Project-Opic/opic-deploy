@@
identifier bs;
expression re, size, front_pad;
statement S;
@@
- re = bioset_init(&bs, size, front_pad,...);
+ bs = bioset_create(size, front_pad);
...
- if (re)
+ if (bs == NULL)
	S
