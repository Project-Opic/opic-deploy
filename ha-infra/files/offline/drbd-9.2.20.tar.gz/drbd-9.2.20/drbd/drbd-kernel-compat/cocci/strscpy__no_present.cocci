@@
@@
- strscpy
+ strlcpy
 (...)
