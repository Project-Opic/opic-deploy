@@
symbol fallthrough;
@@
- fallthrough;
+ ;/* fallthrough */
